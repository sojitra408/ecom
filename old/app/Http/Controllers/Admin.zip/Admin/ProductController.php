<?php

namespace App\Http\Controllers\Admin;

use App\Models\admin\role;
use App\Models\admin\Company;
use App\Models\admin\Product;
use App\Models\admin\NewCategories;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\admin\Images;

use DB;
class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
	 
	 public function __construct(Company $company,NewCategories $new_category,Product $product)
	 {
	 $this->company=$company;
	  $this->product=$product;
	  $this->new_category=$new_category;
	 
	 }
    public function index()
    {
          $company = Company::all();
		  $category = NewCategories::all();
		  $products=$this->product->paginator();
		$title 			  = 	array('pageTitle' => 'Product List');
        return view('admin.product.index',$title)->with(['company'=>$company,'category'=> $category,'products'=> $products ]);
    }
	
	 public function display()
    {
       $company = NewCategories::all();
	    $category = NewCategories::all();
		$title 			  = 	array('pageTitle' => 'Product List');
        $products=$this->product->paginator();
		 
        return view('admin.product.index',$title)->with(['company'=>$company,'category'=> $category,'products'=> $products ]);
       
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         $company = Company::all();
		   $objcategory = new NewCategories();
		    $images = new Images;
    $allimage = $images->getimages();
		  $category =  DB::table('categories as c')->select('c.*','cd.categories_name')->join('categories_description as cd','c.categories_id','cd.categories_id')->get();
		$title 			  = 	array('pageTitle' => 'Product Create');
        return view('admin.product.create',$title)->with(['company'=>$company,'category'=> $category ])->with('allimage', $allimage);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'product_title' => 'required|string|max:255',
            'hs_code' => 'required|string|max:500',
             'sku' => 'required|string|max:255',
			  'cat_id' => 'required'
        ]);
        
        $company =$this->product->create($request->all());
        
        return redirect(route('product.display'))->with('message','Product Created Successfully');
    }
	
	 

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
       $product=$this->product->edit($request);
	   $company=Company::all();
	     $category =  DB::table('categories as c')->select('c.*','cd.categories_name')->join('categories_description as cd','c.categories_id','cd.categories_id')->get();
       
		 $title 			  = 	array('pageTitle' => 'Edit Product');
        
		return view('admin.product.edit',$title)->with('product',$product[0])->with(['company'=>$company,'category'=>$category]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $this->validate($request,[
            'product_title' => 'required|string|max:255',
            'hs_code' => 'required|string|max:500',
             'sku' => 'required|string|max:255',
			  'cat_id' => 'required'
        ]);
		
		 if($request->image_id!==null){
         $uploadImage = $request->image_id;
     }else{
         $uploadImage = $request->oldImage;
     }

        $company =$this->product->update_data($request->all(),$uploadImage);
        return redirect(route('product.display'))->with('message','Product updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $users = admin::find($id);
        $users->roles()->detach();
        $users->delete();
        return redirect (route('company.index'))->with('message','Admin User Deleted Successfully');
    }
}
