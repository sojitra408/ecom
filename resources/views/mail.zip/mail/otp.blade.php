Hey,<br><br>
We bet you are excited to become a part of our TOT world! <br>
Here’s your secret one-time password (OTP) <strong>{{$OTP}}</strong> to verify your email address. <br>Type this carefully so that our system can grant you access.<br>
Remember, the OTP expires in 5 mins. Your time starts now!<br>---<br>Cheers!<br>Team THIS OR THAT