<?php
 $orders= $emaildata['order'];
 $products= $emaildata['products'];
 $address= $emaildata['address'];
 
 ?>
<html>
<head>
    <title></title>
</head>
<body>
    <table align="center" bgcolor="#ffffff" border="0" cellpadding="0"
    cellspacing="0" width="100%">
        <tbody>
            
            <tr style="font-size:0;line-height:0">
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td align="center" valign="top">
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <table width="600" bgcolor="#f78f5a">
                        <tbody>
                           <tr>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <table border="0" cellpadding="0"
                                    cellspacing="0" width="570">
                                        <tbody>
                                            <tr>
                                                <td align="center">
                                                    <a href="#"
                                                    target="_blank"><img alt=
                                                    "TOT"
                                                    src=
                                                    "https://ecomnew.thisorthat.in/front/assets/img/emailer/ylogo.png"
                                                    style="border:0" width=
                                                    "200"></a>
                                                </td>
                                                
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            
                           
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="center" valign="top">
                                    <table bgcolor="#FFFFFF" border="0"
                                    cellpadding="0" cellspacing="0" style=
                                    "overflow:hidden!important;border-radius:3px"
                                    width="580">
                                        <tbody>
                                            
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td align="center">
                                                    <table width="85%">
                                                        <tbody>
                                                            <tr>
                                                                <td align=
                                                                "center">
                                                                    <h2 style=
                                                                    "margin:0!important;font-family:'Helvetica', sans-serif!important;font-size:25px!important;line-height:38px!important;font-weight:600!important;color:#f5905a!important; text-transform:uppercase; font-style:italic">The Postman is on his way to pick up the return <br> <span style=""></span></h2>
                   
				
																 <hr style="height:3px; background:#fdceb0; border:none">  
											 				<h3 style=
											                                                                     "margin:0!important;font-family:'Helvetica', sans-serif!important;font-size:28px!important;line-height:38px!important;font-weight:300!important;color:#f59394!important; text-transform:normal; font-style:normal">Hey! {{$emaildata['name']}}, <img src="https://ecomnew.thisorthat.in/front/assets/img/emailer/cancle.jpg" style="vertical-align:middle"></h3> 
															                                          </td>
                                                            </tr>
                                                            <tr>
                                                                <td align=
                                                                "center" style=
                                                                "font-family:'Helvetica', sans-serif!important;font-size:16px!important;line-height:30px!important;font-weight:400!important;color:#747273!important;">
                                                               The Postman has been notified and he is on his way to pick up your return.<br><br>Kinly keep the product from order <strong>{{$orders->order_id}}</strong> ready with original tag and bill.</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            
                                            
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                          
                            <tr>
                                <td align="center">
                                    <table border="0" cellpadding="0"
                                    cellspacing="0" width="580">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <div style=
                                                    "width:31%;float:left;display:inline">
                                                    <table bgcolor=""
                                                        border="0" cellpadding=
                                                        "0" cellspacing="0"
                                                        style=
                                                        "border-radius:3px!important"
                                                        width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td align=
                                                                    "center"
                                                                    valign=
                                                                    "middle">
                                                                        <a href="#"
                                                                        style=
                                                                        "line-height:50px;display:block;text-decoration:none!important;width:100%"
                                                                        target=
                                                                        "_blank">
                                                                        
                                                                        <span style="font-family:'Helvetica', sans-serif!important;font-size:12px!important;color:#ffffff!important;text-transform:uppercase!important;border-radius:3px!important;text-decoration:none!important;font-weight:400!important">
                                                                        SHOP </span></a>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div style=
                                                    "width:3.5%;min-height:50px;float:left;display:inline">
                                                    </div>
                                                    <div style=
                                                    "width:31%;float:left;display:inline">
                                                    <table bgcolor=""
                                                        border="0" cellpadding=
                                                        "0" cellspacing="0"
                                                        style=
                                                        "border-radius:3px!important"
                                                        width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td align=
                                                                    "center"
                                                                    valign=
                                                                    "middle">
                                                                        <a href="#"
                                                                        style=
                                                                        "line-height:50px;display:block;text-decoration:none!important;width:100%"
                                                                        target=
                                                                        "_blank">
                                                                        
                                                                     
                                                                        <span style="font-family:'Helvetica', sans-serif!important;font-size:12px!important;color:#ffffff!important;text-transform:uppercase!important;border-radius:3px!important;text-decoration:none!important;font-weight:400!important">
                                                                        ABOUT US</span></a>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div style=
                                                    "width:3.5%;min-height:50px;float:left;display:inline">
                                                    </div>
                                                    <div style=
                                                    "width:31%;float:left;display:inline">
                                                    <table bgcolor=""
                                                        border="0" cellpadding=
                                                        "0" cellspacing="0"
                                                        style=
                                                        "border-radius:3px!important"
                                                        width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td align=
                                                                    "center"
                                                                    valign=
                                                                    "middle">
                                                                        <a href="#"
                                                                        style=
                                                                        "line-height:50px;display:block;text-decoration:none!important;width:100%"
                                                                        target=
                                                                        "_blank">
                                                                       
                                                                       
                                                                        <span style="font-family:'Helvetica', sans-serif!important;font-size:12px!important;color:#fff!important;text-transform:uppercase!important;border-radius:3px!important;text-decoration:none!important;font-weight:400!important">
                                                                       HELP</span></a>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <table border="0" cellpadding="0"
                                    cellspacing="0" width="580">
                                        <tbody>
                                            <tr>
                                                <td width="50%" align="center" valign=
                                                "top" style=
                                                                "font-family:'Helvetica', sans-serif!important;font-size:12px!important;line-height:15px!important;font-weight:400!important;color:#ffffff!important;    border-top: solid 1px #fabfbb;    border-right: solid 1px #fabfbb;    border-bottom: solid 1px #fabfbb; padding:15px">Lets Hang Out?<br> <br>
                                                    <a href=
                                                    "#"
                                                    target="_blank"><img alt=
                                                    "Facebook" height="20" src=
                                                    "https://ecomnew.thisorthat.in/front/assets/img/emailer/fb.png"
                                                    style="border:0; padding-right:10px" width=
                                                    "18"></a> <a href=
                                                    "#"
                                                    target="_blank"><img alt=
                                                    "" height="20" src=
                                                    "https://ecomnew.thisorthat.in/front/assets/img/emailer/insta.png"
                                                    style="border:0; padding-right:10px" width=
                                                    "20"></a> <a href=
                                                    "#"
                                                    target="_blank"><img alt=
                                                    "" height="20" src=
                                                    "https://ecomnew.thisorthat.in/front/assets/img/emailer/twt.png"
                                                    style="border:0;padding-right:10px" width=
                                                    "24"></a> <a href=
                                                    "#"
                                                    target="_blank"><img alt=
                                                    "" height="20" src=
                                                    "https://ecomnew.thisorthat.in/front/assets/img/emailer/yt.png"
                                                    style="border:0" width=
                                                    "20"></a>
                                                </td> <td style=
                                                                "font-family:'Helvetica', sans-serif!important;font-size:11px!important;line-height:15px!important;font-weight:400!important;color:#ffffff!important;     border-top: solid 1px #fabfbb;    border-bottom: solid 1px #fabfbb;padding:15px; text-align:center"><strong>Address</strong> <br>
													Soch Retail Pvt. Ltd.<br>
													601 Link Rose, Linking Rd, Above Levi's<br>
													Store, Santacruz West, Mumbai, <br>
													Maharashtra 400054<br>
													<span style="display:none">GSTIN/UIN: 27ADBFS0931L1Z0<br></span>Email: customer.care@thisorthat.in</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td align="center" style=
                                                "font-family:'Helvetica', sans-serif!important;font-weight:400!important;color:#7e8890!important;font-size:12px!important;text-transform:uppercase!important;letter-spacing:.045em!important"
                                                valign="top" > </td>
                                            </tr>
                                            <tr style=
                                            "padding:0;margin:0;font-size:0;line-height:0">
                                            <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td align="center" style=
                                                "font-family:'Helvetica', sans-serif!important;font-weight:400!important;color:#ffffff!important;font-size:11px!important;letter-spacing:.05em!important"
                                                valign="top" colspan="2">&copy; 2021-2022 Soch Retail Pvt. Ltd. All rights reserved.</td>
                                            </tr>
                                            <tr style=
                                            "padding:0;margin:0;font-size:0;line-height:0">
                                            <td>&nbsp;</td>
                                            </tr>
                                           
                                            <tr style=
                                            "padding:0;margin:0;font-size:0;line-height:0">
                                            <td>&nbsp;</td>
                                            </tr>
                                            
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
											
                                           
											
											
											
                                        </tbody>
                                    </table>
									
                                    <table border="0" cellpadding="0"
                                    cellspacing="0" width="600">
                                        <tbody>
                                            <tr><td style="padding:0;margin:0;font-size:0;line-height:0">
                                            	
												<img alt=
												                                                    "TOT"
												                                                    src=
												                                                    "https://ecomnew.thisorthat.in/front/assets/img/emailer/footerreo.jpg"
												                                                    style="border:0" width=
												                                                    "100%">
                                            </td></tr></tbody></table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
					
                </td>
            </tr>
            
        </tbody>
    </table>
</body>
</html>