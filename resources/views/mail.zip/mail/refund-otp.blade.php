<html>
<head>
    <title></title>
</head>
<body>
    <table align="center" bgcolor="#ffffff" border="0" cellpadding="0"
    cellspacing="0" width="100%">
        <tbody>
            
            <tr style="font-size:0;line-height:0">
                <td>&nbsp;</td>
            </tr>
            <tr>
                <td align="center" valign="top">
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <div style=
                    "color:inherit;font-size:inherit;line-height:inherit;margin:inherit;padding:inherit">
                    </div>
                    <table width="600" bgcolor="#ffd0ca">
                        <tbody>
                           <tr>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <table border="0" cellpadding="0"
                                    cellspacing="0" width="570">
                                        <tbody>
                                            <tr>
                                                <td align="center">
                                                    <a href="#"
                                                    target="_blank"><img alt=
                                                    "Munchilicious"
                                                    src=
                                                    "https://new.munchilicious.com/front/img/emailer/email-logo.jpg"
                                                    style="border:0" width=
                                                    "176"></a>
                                                </td>
                                                
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            
                           
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="center" valign="top">
                                    <table bgcolor="#FFFFFF" border="0"
                                    cellpadding="0" cellspacing="0" style=
                                    "overflow:hidden!important;border-radius:3px"
                                    width="580">
                                        <tbody>
                                            
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td align="center">
                                                    <table width="85%">
                                                        <tbody>
                                                            <tr>
                                                                <td align=
                                                                "center">
                                                                    <h2 style=
                                                                    "margin:0!important;font-family:'Helvetica', sans-serif!important;font-size:28px!important;line-height:38px!important;font-weight:200!important;color:#bd684b!important">
                                                                    ONE STEP CLOSER TO THISORTHAT GOODNESS</h2>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td align=
                                                                "center" style=
                                                                "font-family:'Helvetica', sans-serif!important;font-size:16px!important;line-height:30px!important;font-weight:400!important;color:#bd684b!important;">
                                                                Hey,<br> Here's the 4 digit refund otp security code <strong>"{{$emaildata}}"</strong> that'll let you in to your THISORTHAT account.</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            
                                            
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                          
                            <tr>
                                <td align="center">
                                    <table border="0" cellpadding="0"
                                    cellspacing="0" width="580">
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <div style=
                                                    "width:31%;float:left;display:inline">
                                                    <table bgcolor=""
                                                        border="0" cellpadding=
                                                        "0" cellspacing="0"
                                                        style=
                                                        "border-radius:3px!important"
                                                        width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td align=
                                                                    "center"
                                                                    valign=
                                                                    "middle">
                                                                        <a href="#"
                                                                        style=
                                                                        "line-height:50px;display:block;text-decoration:none!important;width:100%"
                                                                        target=
                                                                        "_blank">
                                                                        
                                                                        <span style="font-family:'Helvetica', sans-serif!important;font-size:12px!important;color:#bd684b!important;text-transform:uppercase!important;border-radius:3px!important;text-decoration:none!important;font-weight:400!important">
                                                                        SHOP </span></a>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div style=
                                                    "width:3.5%;min-height:50px;float:left;display:inline">
                                                    </div>
                                                    <div style=
                                                    "width:31%;float:left;display:inline">
                                                    <table bgcolor=""
                                                        border="0" cellpadding=
                                                        "0" cellspacing="0"
                                                        style=
                                                        "border-radius:3px!important"
                                                        width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td align=
                                                                    "center"
                                                                    valign=
                                                                    "middle">
                                                                        <a href="#"
                                                                        style=
                                                                        "line-height:50px;display:block;text-decoration:none!important;width:100%"
                                                                        target=
                                                                        "_blank">
                                                                        
                                                                     
                                                                        <span style="font-family:'Helvetica', sans-serif!important;font-size:12px!important;color:#bd684b!important;text-transform:uppercase!important;border-radius:3px!important;text-decoration:none!important;font-weight:400!important">
                                                                        ABOUT US</span></a>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div style=
                                                    "width:3.5%;min-height:50px;float:left;display:inline">
                                                    </div>
                                                    <div style=
                                                    "width:31%;float:left;display:inline">
                                                    <table bgcolor=""
                                                        border="0" cellpadding=
                                                        "0" cellspacing="0"
                                                        style=
                                                        "border-radius:3px!important"
                                                        width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td align=
                                                                    "center"
                                                                    valign=
                                                                    "middle">
                                                                        <a href="#"
                                                                        style=
                                                                        "line-height:50px;display:block;text-decoration:none!important;width:100%"
                                                                        target=
                                                                        "_blank">
                                                                       
                                                                       
                                                                        <span style="font-family:'Helvetica', sans-serif!important;font-size:12px!important;color:#bd684b!important;text-transform:uppercase!important;border-radius:3px!important;text-decoration:none!important;font-weight:400!important">
                                                                       HELP</span></a>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <table border="0" cellpadding="0"
                                    cellspacing="0" width="580">
                                        <tbody>
                                            <tr>
                                                <td width="50%" align="center" valign=
                                                "top" style=
                                                                "font-family:'Helvetica', sans-serif!important;font-size:12px!important;line-height:15px!important;font-weight:400!important;color:#bd684b!important;    border-top: solid 1px #fff;    border-right: solid 1px #fff;    border-bottom: solid 1px #fff; padding:15px">Lets Hang Out?<br> <br>
                                                    <a href=
                                                    "#"
                                                    target="_blank"><img alt=
                                                    "Facebook" height="25" src=
                                                    "https://new.munchilicious.com/front/img/emailer/fb.jpg"
                                                    style="border:0" width=
                                                    "18"></a> <a href=
                                                    "#"
                                                    target="_blank"><img alt=
                                                    "" height="27" src=
                                                    "https://new.munchilicious.com/front/img/emailer/insta.jpg"
                                                    style="border:0" width=
                                                    "24"></a> <a href=
                                                    "#"
                                                    target="_blank"><img alt=
                                                    "" height="20" src=
                                                    "https://new.munchilicious.com/front/img/emailer/twt.jpg"
                                                    style="border:0" width=
                                                    "24"></a> <a href=
                                                    "#"
                                                    target="_blank"><img alt=
                                                    "" height="21" src=
                                                    "https://new.munchilicious.com/front/img/emailer/yt.jpg"
                                                    style="border:0" width=
                                                    "26"></a>
                                                </td> <td style=
                                                                "font-family:'Helvetica', sans-serif!important;font-size:11px!important;line-height:15px!important;font-weight:400!important;color:#bd684b!important;     border-top: solid 1px #fff;    border-bottom: solid 1px #fff;padding:15px"><strong>Soch Foods LLP</strong> <br>
													GB7 & GB8, Virwani Industrial Estat,<br>
													Western Express Highway, Goregaon (E)<br>
													Mumbai, Maharashtra - 400063.<br>
													GSTIN/UIN: 27ADBFS0931L1Z0<br>Email: care@sochfoods.com</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td align="center" style=
                                                "font-family:'Helvetica', sans-serif!important;font-weight:400!important;color:#7e8890!important;font-size:12px!important;text-transform:uppercase!important;letter-spacing:.045em!important"
                                                valign="top" > </td>
                                            </tr>
                                            <tr style=
                                            "padding:0;margin:0;font-size:0;line-height:0">
                                            <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td align="center" style=
                                                "font-family:'Helvetica', sans-serif!important;font-weight:400!important;color:#bd684b!important;font-size:11px!important;letter-spacing:.05em!important"
                                                valign="top" colspan="2">&copy; 2021-2022 Soch Foods LLP All rights reserved.</td>
                                            </tr>
                                            <tr style=
                                            "padding:0;margin:0;font-size:0;line-height:0">
                                            <td>&nbsp;</td>
                                            </tr>
                                           
                                            <tr style=
                                            "padding:0;margin:0;font-size:0;line-height:0">
                                            <td>&nbsp;</td>
                                            </tr>
                                            
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
											
                                           
											
											
											
                                        </tbody>
                                    </table>
									
                                    <table border="0" cellpadding="0"
                                    cellspacing="0" width="600">
                                        <tbody>
                                            <tr><td style="padding:0;margin:0;font-size:0;line-height:0">
                                            	
												<img alt=
												                                                    "Munchilicious"
												                                                    src=
												                                                    "https://new.munchilicious.com/front/img/emailer/footer.jpg"
												                                                    style="border:0" width=
												                                                    "100%">
                                            </td></tr></tbody></table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
					
                </td>
            </tr>
            
        </tbody>
    </table>
</body>
</html>
